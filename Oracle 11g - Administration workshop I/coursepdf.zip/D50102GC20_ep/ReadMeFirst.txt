The ep file that you have just unzipped contains material that equips you to conduct an ILT / LVC in an interactive manner. You will find the following folders in the ep zip file:


1. Presentation_material  (D50102GC20_ep.pdf) - This contains the electronic presentation material for LVC delivery (note - these materials are also used in the ILT class). The following materials are included:

2. Individual Pdf  - contains individual pdfs of ep.pdf

3. Practice-and-solution - contains pdfs of practices and solutions


