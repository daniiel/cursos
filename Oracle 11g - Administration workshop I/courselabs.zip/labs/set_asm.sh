. oraenv <<EOI
+ASM
EOI

