. oraenv <<EOI
orcl
EOI

