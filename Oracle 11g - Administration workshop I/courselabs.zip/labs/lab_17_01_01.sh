# Oracle Database 11g: Administration Workshop I
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#

cd ~/labs

. set_db.sh

sqlplus -S /nolog @lab_17_01_01.sql
