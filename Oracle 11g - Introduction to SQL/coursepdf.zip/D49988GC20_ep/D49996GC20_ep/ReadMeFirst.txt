The ep file that you have just unzipped contains material that equips you to conduct an ILT / LVC in an interactive manner. You will find the following folders in the ep zip file:
1) presentation_material - this folder contains the electronic presentation which is the same that is available as part of an ILT material.
   a) D49996GC20_ep.pdf
   b) individual_pdfs
   c) practice&solutions 

2) quizzes_webex_format - This contains the .atp files of the Lesson quizzes that you can import into Webex.

Please use the following link to access the Online Instructor Guide (OIG):

http://stcwiki.us.oracle.com/index.php/OIG:11gDBR2_D49996GC20_11gR2_SQL1



