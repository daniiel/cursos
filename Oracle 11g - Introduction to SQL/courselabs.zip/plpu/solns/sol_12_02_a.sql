CREATE TABLE emps AS
  SELECT * FROM employees;
