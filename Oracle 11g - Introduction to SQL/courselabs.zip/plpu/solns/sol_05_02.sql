-- for student ora61, as an example.

EXECUTE employee_report('REPORTS_DIR','sal_rpt61.txt') 