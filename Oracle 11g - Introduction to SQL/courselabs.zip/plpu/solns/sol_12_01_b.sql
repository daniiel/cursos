EXECUTE deptree_fill('PROCEDURE', USER, 'add_employee')
