SET SERVEROUTPUT ON

EXECUTE new_job ('SY_ANAL', 'System Analyst', 6000)

