UPDATE employees
  SET salary = salary + 2000
WHERE job_id = 'IT_PROG';
