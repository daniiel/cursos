EXECUTE video_pkg.new_member('Haas', 'James', 'Chestnut Street', 'Boston', '617-123-4567')
EXECUTE  video_pkg.new_member('Biri', 'Allan',  'Hiawatha Drive', 'New York', '516-123-4567')
