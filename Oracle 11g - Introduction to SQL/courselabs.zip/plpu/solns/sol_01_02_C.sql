EXECUTE upd_job ('IT_WEB', 'Web Master')
SELECT * FROM jobs WHERE job_id = 'IT_WEB';