INSERT INTO departments (department_id, department_name)
VALUES (15, 'Security');
COMMIT;
