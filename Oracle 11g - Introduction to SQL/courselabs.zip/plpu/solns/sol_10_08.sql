DESCRIBE user_errors
/
SELECT * 
FROM user_errors;