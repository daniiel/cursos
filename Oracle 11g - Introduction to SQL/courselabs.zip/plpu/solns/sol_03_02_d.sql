SELECT *
FROM employees
WHERE last_name = 'Smith';