EXECUTE compile_pkg.recompile

