SELECT *
FROM my_contacts;
