EXECUTE deptree_fill('FUNCTION', USER, 'valid_deptid')
