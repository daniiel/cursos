EXECUTE table_pkg.make('my_contacts', 'id number(4), name varchar2(40)')
