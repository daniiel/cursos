ALTER TABLE employees
  ADD (totsal NUMBER(9,2));
