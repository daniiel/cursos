UPDATE employees
  SET salary = 2800
WHERE employee_id = 115;
