-- You must run code_02_08_as.sql before running this code example.

SELECT job_id, get_sal(employee_id)
FROM employees;
