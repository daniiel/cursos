-- Run code_08_25_cs.sql before this code example. 

UPDATE employees
  SET department_id = 999 
WHERE employee_id = 170;
