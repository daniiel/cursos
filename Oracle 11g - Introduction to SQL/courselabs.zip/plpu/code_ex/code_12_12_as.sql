-- Run code_12_11_bs.sql before this code example. 

SELECT   nested_level, type, name
FROM     deptree
ORDER BY seq#;
