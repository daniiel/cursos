SELECT object_name, status 
FROM user_objects 
WHERE object_type = 'VIEW';