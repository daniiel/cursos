-- Run code_04_14_as.sql before running this code. 

SELECT taxes_pkg.tax(salary), salary, last_name
FROM   employees;
