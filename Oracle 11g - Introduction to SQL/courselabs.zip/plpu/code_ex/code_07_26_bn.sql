-- Run code_07_26_as.sql before running this code example. 

SET SERVEROUTPUT ON
EXECUTE update_salary(108)
