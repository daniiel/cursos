-- Run code_11_10_as before running this code example. 

SELECT name, plsql_ccflags 
FROM USER_PLSQL_OBJECT_SETTINGS
WHERE name = 'P';