-- Run code_09_11_s.sql before running this code example. 

UPDATE employees
SET salary = 3400
WHERE last_name = 'Stiles';
