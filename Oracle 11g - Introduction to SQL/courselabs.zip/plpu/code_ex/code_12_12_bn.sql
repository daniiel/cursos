-- Run code_12_11_bs.sql before this code example. 

SELECT * 
FROM   ideptree;
