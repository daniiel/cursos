-- Run after code_08_19_as.sql

UPDATE employees
SET salary = 15500
WHERE last_name = 'Russell';
