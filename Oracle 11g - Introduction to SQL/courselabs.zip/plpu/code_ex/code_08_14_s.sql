INSERT INTO departments 
   (department_id,department_name, location_id)
VALUES (400, 'CONSULTING', 2400);
