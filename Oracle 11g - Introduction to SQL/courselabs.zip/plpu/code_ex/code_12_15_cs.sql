-- Run code_12_15_as.sql before running this code example. 

ALTER TABLE t2 ADD (col_d VARCHAR2(20));