-- Run code_04_19_s.sql before running this code example. 

EXECUTE curs_pkg.close
