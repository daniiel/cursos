SELECT name, type, plsql_code_type AS CODE_TYPE, plsql_optimize_level AS OPT_LVL
FROM   user_plsql_object_settings;