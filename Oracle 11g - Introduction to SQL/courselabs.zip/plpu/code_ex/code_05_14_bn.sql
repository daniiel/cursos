-- Run code_05_14_15_s.sql before running this code example. 

EXECUTE sal_status('REPORTS_DIR', 'salreport2.txt')