-- You must run code_02_20_as.sql before running this code example. 

SELECT f(p_parameter_5 => 10) FROM DUAL;
