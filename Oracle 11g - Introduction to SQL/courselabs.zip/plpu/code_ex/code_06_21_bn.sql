-- Run code_06_21_as.sql before running this code example. 

EXECUTE insert_row('countries', 'LB', 'Lebanon', 4)