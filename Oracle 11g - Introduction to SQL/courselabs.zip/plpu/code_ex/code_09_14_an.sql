UPDATE employees
SET salary = 3400
WHERE last_name = 'Stiles';
