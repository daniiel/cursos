-- You must run code_01_24_as.sql before running this code examle. 

DROP PROCEDURE raise_salary;
