SELECT last_name, job_id, commission_pct
FROM   employees
WHERE  commission_pct IS NULL;