SELECT last_name ||' is a '||job_id 
       AS "Employee Details"
FROM   employees;