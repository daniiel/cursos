SELECT employee_id, last_name, job_id, department_id
FROM   employees
WHERE  department_id = 90 ;
