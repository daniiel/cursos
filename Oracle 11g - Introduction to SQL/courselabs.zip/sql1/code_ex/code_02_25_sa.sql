SELECT   last_name, job_id, department_id, hire_date
FROM     employees
ORDER BY 3;
