SELECT last_name AS name, commission_pct comm
FROM   employees;