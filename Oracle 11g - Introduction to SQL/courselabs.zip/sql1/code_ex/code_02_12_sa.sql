SELECT	first_name
FROM 	employees
WHERE	first_name LIKE 'S%' ;
