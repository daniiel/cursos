SELECT department_id
FROM   employees;
