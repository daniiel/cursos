SELECT last_name "Name", salary*12 "Annual Salary"
FROM   employees;