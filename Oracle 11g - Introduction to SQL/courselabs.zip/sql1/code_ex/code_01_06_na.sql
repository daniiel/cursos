SELECT  department_id, department_name, manager_id, location_id
FROM    departments;