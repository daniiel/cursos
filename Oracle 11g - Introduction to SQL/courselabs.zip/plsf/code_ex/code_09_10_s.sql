BEGIN
 add_dept;
END;
/
SELECT department_id, department_name FROM dept WHERE department_id=280;
/
