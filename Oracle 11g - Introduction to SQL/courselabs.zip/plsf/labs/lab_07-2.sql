DROP TABLE top_salaries;
CREATE TABLE top_salaries
(salary	NUMBER(8,2))

