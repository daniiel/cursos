DROP TABLE emp;

CREATE TABLE emp AS SELECT * FROM employees;

ALTER TABLE    emp  ADD stars	VARCHAR2(50);
